
from django.http import HttpResponse
from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login,logout, authenticate
from django.contrib import messages
from .form import UserForm,SendCourier
from .models import User
import random



def home(request):
	return render(request, 'source/home.html')

def about(request):
	return render(request, 'source/about.html')

def login(request):
	if request.method == 'POST':
		form = AuthenticationForm(request=request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				#login(request, user)
				messages.info(request, f"You are now logged in as {username}")
				return redirect('user/courier')
			else:
				messages.error(request, "Invalid username or password.")
		else:
			messages.error(request, "Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request,
				  template_name="source/login.html",
				  context={"form": form})


def courier_list(request):
	#form = SendCourier()
	context = {}
	context['form'] = SendCourier()
	if request.method == 'POST':
		courier_form = SendCourier(request.POST)
		item_type= request.POST.get('item_type')
		sender_name = request.POST.get('sender_name')
		print (item_type,"1111111")
	return render(request=request, template_name='user/list_user.html',context=context)


def user_track(request):
	return render(request, 'user/user_track.html')


def logout_request(request):
	logout(request)
	messages.info(request, "Logged out successfully!")
	return redirect("home")

def user_sinup(request):
	if request.method == 'POST':
		user_form = UserForm(request.POST)
		if user_form.is_valid():
			user = User()
			user.user_name =  user_form.cleaned_data.get('firstname')#request.POST.get('firstname')
			user.user_pass =  request.POST.get('password1')
			user.user_phone =  request.POST.get('phoneNumber')
			user.user_last_name =  request.POST.get('lastname')
			user.user_id = random.randint(10000, 999999)
			user.save()
			user_form = UserForm()


	else:
		user_form = UserForm()
	return render(request,"source/sinup.html",{'form':user_form})