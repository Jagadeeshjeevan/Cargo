from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import render,redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login,logout, authenticate
from django.contrib import messages
from .form import UserForm,SendCourier
from .models import User , Courier
import random,uuid
from .serializers import VendorSerializer



def home(request):
	return render(request, 'source/home.html')

def about(request):
	return render(request, 'source/about.html')

def login(request):
	if request.method == 'POST':
		form = AuthenticationForm(request=request, data=request.POST)
		if form.is_valid():
			username = form.cleaned_data.get('username')
			password = form.cleaned_data.get('password')
			user = authenticate(username=username, password=password)
			if user is not None:
				request.session['username'] = "jag"
				messages.info(request, f"You are now logged in as {username}")
				return redirect('user/courier')
			else:
				messages.error(request, "Invalid username or password.")
		else:
			messages.error(request, "Invalid username or password.")
	form = AuthenticationForm()
	return render(request=request,
				  template_name="source/login.html",
				  context={"form": form})

def courier_list(request):
	if "username" not in request.session:
		return redirect(login)
	userID = "5678"
	context = {}
	context['form'] = SendCourier()
	### Get List of Packets

	fetch = Courier.objects.filter(user_id=userID)
	context['details'] = fetch
	context['status'] = {0: "yet to Receive Packet", 1: "", 2: "Deleivered", 3: "Packet Return"}
	for i in fetch:
		print(i.uniq_id,i.receiver_name)
	### Add New Courier
	if request.method == 'POST':
		courier = Courier()
		context['mess'] = "Sucess"
		courier_form = SendCourier(request.POST)
		details = {"item_type":"item_type","send_to":"receiver_name","priority_type":"priority_type","send_address":"send_add","send_city":"sender_city","send_state":"sender_state","send_country":"sender_coun","des_address":"rec_add","des_city":"rec_city","des_state":"rec_state","des_country":"rec_con","des_pin":"rec_pin"}
		for detail in details.keys():
			setattr(courier, details[detail] , request.POST.get(detail) )
		courier.uniq_id = random.randint(100000, 9999999)
		courier.user_id = userID
		courier.save()
	return render(request=request, template_name='user/list_user.html',context=context)


def user_track(request):
	if "username" not in request.session:
		return redirect(login)
	context = {}
	if request.method == 'POST' :
		courier = Courier()
		tracker_id = request.POST.get('track_id')
		if tracker_id is not None and tracker_id != "":
			courier_details = Courier.objects.filter(uniq_id=tracker_id)
			context['courier_details']=courier_details
	return render(request, 'user/user_track.html',context=context)


def logout_request(request):
	logout(request)
	messages.info(request, "Logged out successfully!")
	return redirect("home")

def user_sinup(request):
	if request.method == 'POST':
		user_form = UserForm(request.POST)
		if user_form.is_valid():
			user = User()
			user.user_name =  user_form.cleaned_data.get('firstname')#request.POST.get('firstname')
			user.user_pass =  request.POST.get('password1')
			user.user_phone =  request.POST.get('phoneNumber')
			user.user_last_name =  request.POST.get('lastname')
			user.user_id = random.randint(10000, 999999)
			user.save()
			user_form = UserForm()


	else:
		user_form = UserForm()
	return render(request,"source/sinup.html",{'form':user_form})

class VendorViews(APIView):
    def post(self, request):
        serializer = VendorSerializer(data=request.data)
        if serializer.is_valid():
            print ("valid Serializer")
            serializer.save()
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)