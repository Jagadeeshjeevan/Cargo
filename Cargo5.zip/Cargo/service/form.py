from django import forms
from django.core.exceptions import ValidationError


class UserForm(forms.Form):
    firstname = forms.CharField(label="Enter first name",max_length=50)
    lastname  = forms.CharField(label="Enter last name", max_length = 100)
    password1 = forms.CharField(label="password", max_length = 100,widget=forms.PasswordInput())
    password2 = forms.CharField(label="re-password", max_length = 100,widget=forms.PasswordInput())
    phoneNumber = forms.CharField(label="phonenumber", max_length = 100)

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get("password1")
        p2 = cleaned_data.get("password2")
        phoneNum = cleaned_data.get("phoneNumber")
        if p1 != p2 :
            msg = "Password are not match "
            self.add_error('password1', msg)
        if len(phoneNum) < 6:
            msg = "Invalid Mobile Number "
            self.add_error('phoneNumber', msg)
        return cleaned_data


class SendCourier(forms.Form):
    item_type = forms.CharField(label="Item Type", max_length=50)


class AddVendor(forms.Form):
    vendor_name = forms.CharField(max_length=100)
    vendor_pick_up = forms.CharField(max_length=100)
    vendor_drop = forms.CharField(max_length=100)

class Change_password(forms.Form):
    Old_Password = forms.CharField(max_length=100)
    New_Password = forms.CharField(max_length=100)
    Re_type_Password = forms.CharField(max_length=100)