from django.db import models

class Courier(models.Model):
    auto_increment_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(blank=True, null=True)
    uniq_id = models.IntegerField(blank=True, null=True)
    item_type = models.CharField(max_length=30)
    receiver_name = models.CharField(max_length=30)
    priority_type = models.CharField(max_length=30)
    description = models.CharField(max_length=30)
    send_add = models.CharField(max_length=30)
    sender_city = models.CharField(max_length=30)
    sender_address = models.CharField(max_length=100)
    sender_state = models.CharField(max_length=30)
    sender_coun = models.CharField(max_length=30)
    sen_pin = models.CharField(max_length=30, default=None)
    rec_add = models.CharField(max_length=100)
    rec_city= models.CharField(max_length=30)
    rec_state =  models.CharField(max_length=30)
    rec_con = models.CharField(max_length=30)
    rec_pin = models.CharField(max_length=30)
    status = models.CharField(max_length=7, default='0', editable=False)
    order_date = models.DateTimeField(auto_now=True)
    vendor_id = models.IntegerField(blank=True, null=True)
    amount = models.IntegerField(blank=True, null=True)


class Trans_courier(models.Model):
    auto_id = models.AutoField(primary_key=True)
    track_order = models.DateTimeField(auto_now=True)
    details = models.CharField(max_length=100)
    location = models.CharField(max_length=30)
    vendor_id = models.CharField(max_length=30)
    courier_id = models.CharField(max_length=100)
    status = models.CharField(max_length=7, default='0', editable=True)

class Vendor_details(models.Model):
    auto_vendor_id = models.AutoField(primary_key=True)
    vendor_name = models.CharField(max_length=100)
    vendor_id = models.IntegerField(blank=True, null=True)
    vendor_pick_up = models.CharField(max_length=100)
    vendor_drop = models.CharField(max_length=100)
    vendor_email = models.CharField(max_length=100,default=None)
    vendor_type = models.CharField(max_length=30,default=None)
    company_name = models.CharField(max_length=100,default=None)
    vendor_phone = models.CharField(max_length=100,default=None)
    vendor_address = models.CharField(max_length=100, default=None)
    vendor_state = models.CharField(max_length=100, default=None)
    vendor_country = models.CharField(max_length=100, default=None)
    vendor_pincode = models.CharField(max_length=100, default=None)
    status = models.CharField(max_length=7, default='0', editable=True)
    vendor_unique = models.IntegerField(blank=True, null=True)


class User(models.Model):
    user_auto_id = models.AutoField(primary_key=True)
    user_id = models.IntegerField(blank=True, null=True)
    user_name = models.CharField(max_length=100)
    user_last_name=models.CharField(max_length=100,default=None)
    user_pass = models.CharField(max_length=100)
    user_phone = models.CharField(max_length=100)
    user_first_name = models.CharField(max_length=30,default=None)
    email_id = models.CharField(max_length=30,default=None)

