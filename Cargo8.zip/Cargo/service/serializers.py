#https://stackabuse.com/creating-a-rest-api-with-django-rest-framework/
from rest_framework import serializers
from .models import Trans_courier

class VendorSerializer(serializers.ModelSerializer):
    details = serializers.CharField(max_length=200)
    location = serializers.CharField(max_length=200)
    vendor_id = serializers.CharField(max_length=200)
    status=serializers.CharField(max_length=200)
    class Meta:
        model = Trans_courier
        fields = ('details','location','vendor_id','status','courier_id')