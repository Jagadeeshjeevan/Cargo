from django import forms
from django.core.exceptions import ValidationError


class UserForm(forms.Form):
    firstname = forms.CharField(label="Enter first name",max_length=50)
    lastname  = forms.CharField(label="Enter last name", max_length = 100)
    username = forms.CharField(label="Enter user name", max_length=100)
    password1 = forms.CharField(label="password", max_length = 100,widget=forms.PasswordInput())
    password2 = forms.CharField(label="re-password", max_length = 100,widget=forms.PasswordInput())
    phoneNumber = forms.CharField(label="phonenumber", max_length = 100)

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get("password1")
        p2 = cleaned_data.get("password2")
        phoneNum = cleaned_data.get("phoneNumber")
        if p1 != p2 :
            msg = "Password are not match "
            self.add_error('password1', msg)
        if len(phoneNum) < 6:
            msg = "Invalid Mobile Number "
            self.add_error('phoneNumber', msg)
        return cleaned_data


class SendCourier(forms.Form):
    item_type = forms.CharField(label="Item Type", max_length=50)


class AddVendor(forms.Form):
    vendor_name = forms.CharField(max_length=100)
    vendor_pick_up = forms.CharField(max_length=100)
    vendor_drop = forms.CharField(max_length=100)

class Change_password(forms.Form):
    Old_Password = forms.CharField(max_length=100,widget=forms.PasswordInput)
    New_Password = forms.CharField(max_length=100,widget=forms.PasswordInput)
    Re_type_Password = forms.CharField(max_length=100,widget=forms.PasswordInput)


class VendorForm(forms.Form):
    name = forms.CharField(label="Owner Name",max_length=50)
    company_name  = forms.CharField(label="Company Name", max_length = 100)
    vendor_email = forms.CharField(label="Email ID", max_length=100)
    transport = forms.CharField(label="Modes of Transport", max_length = 100)
    vendor_phone = forms.CharField(label="Phone Number", max_length=100)
    vendor_address = forms.CharField(label="Address", max_length=100)
    vendor_state = forms.CharField(label="State", max_length=100)
    vendor_pincode = forms.CharField(label="Pincode", max_length=100)
    vendor_country = forms.CharField(label="Country", max_length=100)

    def clean(self):
        cleaned_data = super().clean()
        p1 = cleaned_data.get("name")
        p2 = cleaned_data.get("company_name")

        return cleaned_data

class Vendor(forms.Form):
    Vendor_ID = forms.CharField(max_length=100,widget=forms.PasswordInput)
    Vendor_Unique = forms.CharField(max_length=100,widget=forms.PasswordInput)


class Vendor_page(forms.Form):
    vendor_id = forms.CharField(label="Vendor ID",max_length=50)
    courier_id = forms.CharField(label="Courier ID",max_length=50)
    details = forms.CharField(label="Details",max_length=50)
    location = forms.CharField(label="Location",max_length=50)
    status = forms.CharField(label="status",max_length=50)