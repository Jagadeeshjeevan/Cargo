"""cargo URL Configuration

The `urlpatterns` list routes URLs to views. For more information please see:
    https://docs.djangoproject.com/en/4.0/topics/http/urls/
Examples:
Function views
    1. Add an import:  from my_app import views
    2. Add a URL to urlpatterns:  path('', views.home, name='home')
Class-based views
    1. Add an import:  from other_app.views import Home
    2. Add a URL to urlpatterns:  path('', Home.as_view(), name='home')
Including another URLconf
    1. Import the include() function: from django.urls import include, path
    2. Add a URL to urlpatterns:  path('blog/', include('blog.urls'))
"""
from django.contrib import admin
from django.urls import path
from django.urls import include, path
from django.contrib.auth import views as auth_views
from service import views as app_view

urlpatterns = [
    path('admin/', admin.site.urls),

    # UI App
    path('', app_view.home, name='home'),
    path('about', app_view.about, name='about'),
    path('login', app_view.login, name='login'),
    path('Logout', app_view.logout_request, name='logout'),
    path('tracking', app_view.tracking, name='tracking'),
    path('signup', app_view.user_signup, name='signup'),
    path('vendor_login', app_view.vendor_login, name='vendor_login'),
    path('vendor_signup', app_view.vendor_signup, name='vendor_signup'),

    # user
    path('user/courier', app_view.courier_list, name='courier_list'),
    path('user/payment', app_view.user_payment, name='user_payment'),
    path('user/change-password', app_view.change_password, name='change_password'),
    path('user/track', app_view.user_track, name='user_track'),
    path('<int:userid>/results', app_view.user_details, name='user_details'),
    path('ajax_payment/', app_view.ajax_payment, name='ajax_payment'),
    path('ajax_vendor_accept/', app_view.ajax_vendor_accept, name='ajax_vendor_accept'),

    # admin
    path('Admin/home', app_view.admin_home, name='admin_home'),
    path('Admin/vendors', app_view.admin_vendor, name='admin_vendor'),
    path('Admin/tracking', app_view.admin_track, name='admin_track'),
    path('Admin/courier', app_view.admin_courier, name='admin_courier'),
    path('about', app_view.about, name='about'),

    # Vendor
    path('vendor/new_cargo', app_view.new_cargo, name='new_cargo'),
    path('vendor/courier', app_view.courier, name='courier'),
    path('vendor/api', app_view.vendor_api, name='vendor_api'),
    #API
    path('vendor', app_view.VendorViews.as_view())


]
