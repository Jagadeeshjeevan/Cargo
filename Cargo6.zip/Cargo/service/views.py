from django.http import HttpResponse
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status
from django.shortcuts import render, redirect
from django.contrib.auth.forms import UserCreationForm, AuthenticationForm
from django.contrib.auth import login, logout, authenticate
from django.contrib import messages
from .form import UserForm, SendCourier , Change_password , VendorForm
from .models import User, Courier, Trans_courier, Vendor_details
import random, uuid
from .serializers import VendorSerializer
import pgeocode





distance = pgeocode.GeoDistance('in')


def home(request):
    return render(request, 'source/home.html')


def about(request):
    return render(request, 'source/about.html')


def login(request):
    form = AuthenticationForm()
    if request.method == 'POST':
        form = AuthenticationForm(request=request, data=request.POST)
        user = User.objects.filter(user_name=request.POST.get('username'), user_pass=request.POST.get('password'))
        if form.is_valid():
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password')
            admin = authenticate(username=username, password=password)
            if admin is not None:
                request.session['username'] = username
                request.session['admin'] = "admin"
                messages.info(request, f"You are now logged in as {username}")
                return redirect('Admin/home')
            else:
                messages.error(request, "Invalid username or password.")
        elif user:
            request.session['username'] = request.POST.get('username')
            request.session['userid'] = user[0].user_id
            return redirect('user/courier')
        else:
            messages.error(request, "Invalid username or password.")
    return render(request=request, template_name="source/login.html", context={"form": form})


def vendor_login(request):
    form = AuthenticationForm()
    if request.method == 'POST':
        user = User.objects.filter(user_name=request.POST.get('username'), user_pass=request.POST.get('password'))
        request.session['username'] = request.POST.get('username')
        request.session['userid'] = user[0].user_id
        return redirect('user/courier')
    return render(request=request, template_name="source/vendor_login.html", context={"form": form})

def user_details(request,userid):
    context={}
    user_details = User.objects.filter(user_id=userid)
    trans_details = Courier.objects.filter(user_id=userid)
    context['user_details'] = user_details
    context['trans_details'] = trans_details
    return render(request=request, template_name="adm/user_details.html",context=context)



def change_password(request):
    if "username" not in request.session:
        return redirect(login)
    context = {}

    form = Change_password()
    if request.method == 'POST':
        userID = request.session.get('userid')
        a = User.objects.get(user_id=userID)
        old_password = request.POST.get('Old_Password')
        new_password = request.POST.get('New_Password')
        re_password = request.POST.get('Re_type_Password')
        if new_password != re_password:
            return render(request, 'user/change_pass.html', context={"form": form,"incorrect":"incorrect"})
        a.user_pass = new_password
        a.save()
        return render(request, 'user/change_pass.html', context={"form": form,"sucess":"sucess"})

    return render(request, 'user/change_pass.html', context={"form": form})


def courier_list(request):
    if "username" not in request.session:
        return redirect(login)
    userID = request.session.get('userid')
    context = {}
    context['form'] = SendCourier()
    # Get List of Packets

    fetch = Courier.objects.filter(user_id=request.session.get('userid'))
    order_status = {'0': "Order Placed", '1': "", '2': "Payment Success", '3': "Cancel Order", '4': "Deleveried"}

    for num,i in enumerate(fetch):
        fetch[num].status = order_status[str(i.status)]
    context['details'] = fetch
    # Add New Courier
    if request.method == 'POST':
        courier_id = random.randint(100000, 9999999)
        courier = Courier()
        trans_courier = Trans_courier()
        context['mess'] = "Sucess"
        details = {"item_type": "item_type", "send_to": "receiver_name", "priority_type": "priority_type",
                   "send_address": "send_add", "send_city": "sender_city", "send_state": "sender_state",
                   "send_country": "sender_coun", "des_address": "rec_add", "des_city": "rec_city",
                   "des_state": "rec_state", "des_country": "rec_con", "des_pin": "rec_pin","sen_pin":"sen_pin"}
        for detail in details.keys():
            setattr(courier, details[detail], request.POST.get(detail))
        courier.uniq_id = courier_id
        courier.user_id = userID
        cal_amount = distance.query_postal_code(request.POST.get('sen_pin'),request.POST.get('des_pin'))
        priority = {"High":0.75 , "Medium":0.5 , "Low":0.3}
        courier.amount = cal_amount *priority[request.POST.get('priority_type')]
        courier.save()
        trans_courier.courier_id = courier_id
        trans_courier.details = "Order Placed"
        trans_courier.save()
    return render(request=request, template_name='user/list_user.html', context=context)


def tracking(request):
    context = {}
    if request.method == 'POST':
        tracker_id = request.POST.get('track_id')
        if tracker_id is not None and tracker_id != "":
            courier_details = Trans_courier.objects.filter(courier_id=tracker_id)

            if courier_details:
                context['courier_details'] = courier_details
            else:
                context['error'] = "Invalid ID"
    return render(request, 'source/track.html', context=context)


def user_track(request):
    if "username" not in request.session:
        return redirect(login)
    context = {}
    if request.method == 'POST':
        courier = Courier()
        tracker_id = request.POST.get('track_id')
        if tracker_id is not None and tracker_id != "":
            courier_details = Courier.objects.filter(uniq_id=tracker_id, user_id=request.session.get('userid'))
            trans_details = Trans_courier.objects.filter(courier_id=tracker_id)
            context['courier_details'] = courier_details
            context['trans_details'] = trans_details
    return render(request, 'user/user_track.html', context=context)


def logout_request(request):
    logout(request)
    messages.info(request, "Logged out successfully!")
    return redirect("home")


def user_signup(request):
    if request.method == 'POST':
        user_form = UserForm(request.POST)
        if user_form.is_valid():
            user = User()
            user.user_first_name = user_form.cleaned_data.get('firstname')  # request.POST.get('firstname')
            user.user_name = user_form.cleaned_data.get('username')
            user.user_pass = request.POST.get('password1')
            user.user_phone = request.POST.get('phoneNumber')
            user.user_last_name = request.POST.get('lastname')
            user.user_id = random.randint(10000, 999999)
            user.save()
            user_form = UserForm()
    else:
        user_form = UserForm()
    return render(request, "source/sinup.html", {'form': user_form})

def vendor_signup(request):
    if request.method == 'POST':
        vendor_form = VendorForm(request.POST)
        if vendor_form.is_valid():
            vendor = Vendor_details()
            vendor.vendor_name = vendor_form.cleaned_data.get('name')  # request.POST.get('firstname')
            vendor.company_name = vendor_form.cleaned_data.get('company_name')
            vendor.vendor_email = vendor_form.cleaned_data.get('vendor_email')
            vendor.vendor_type = vendor_form.cleaned_data.get('transport')
            vendor.vendor_address = vendor_form.cleaned_data.get('vendor_address')
            vendor.vendor_state = vendor_form.cleaned_data.get('vendor_state')
            vendor.vendor_pincode = vendor_form.cleaned_data.get('vendor_pincode')
            vendor.vendor_country = vendor_form.cleaned_data.get('vendor_country')
            vendor.vendor_phone = vendor_form.cleaned_data.get('vendor_phone')
            vendor.vendor_id = random.randint(10000, 999999)
            vendor.save()
            vendor_form = VendorForm()
    else:
        vendor_form = VendorForm()
    return render(request, "source/vendor_signup.html", {'form': vendor_form})

def user_payment(request):
    return render(request, 'user/change_pass.html')


def admin_home(request):
    if "username" not in request.session and "admin" not in request.session:
        return redirect(login)
    else:
        context = {}
        user_details = User.objects.all()
        context['user_details'] = user_details
        return render(request, 'adm/home.html', context=context)


def admin_vendor(request):
    if "username" not in request.session and "admin" not in request.session:
        return redirect(login)
    else:
        context = {}
        vendor_details = Vendor_details.objects.all()
        context['vendor_details'] = vendor_details
        return render(request, 'adm/vendor.html', context=context)


def admin_track(request):
    if "username" not in request.session and "admin" not in request.session:
        return redirect(login)
    context = {}
    if request.method == 'POST':
        courier = Courier()
        tracker_id = request.POST.get('track_id')
        if tracker_id is not None and tracker_id != "":
            courier_details = Courier.objects.filter(uniq_id=tracker_id)
            context['courier_details'] = courier_details
    return render(request, 'adm/track.html', context=context)


def admin_courier(request):
    if "username" not in request.session and "admin" not in request.session:
        return redirect(login)
    else:
        context = {}
        courier_details = Courier.objects.all()
        context['courier_details'] = courier_details
        print(context)
    return render(request, 'adm/courier.html', context=context)


def add_vendor(request):
    if "username" not in request.session and "admin" not in request.session:
        return redirect(login)
    if request.method == 'POST':
        add_ven = Vendor_details()
        add_ven.vendor_name = request.POST.get('vendor_name')
        vendor_email = request.POST.get('vendor_email')
        vendor_address = request.POST.get('vendor_address')
        vendor_type = request.POST.get('vendor_type')
        add_ven.save()

    return render(request, 'adm/add_vendor.html')


class VendorViews(APIView):
    def post(self, request):
        serializer = VendorSerializer(data=request.data)
        if serializer.is_valid():
            print("valid Serializer")
            serializer.save()
            return Response({"status": "success", "data": serializer.data}, status=status.HTTP_200_OK)
        else:
            return Response({"status": "error", "data": serializer.errors}, status=status.HTTP_400_BAD_REQUEST)
